package com.rangdhanu.scheduler

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class TaskWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = System.currentTimeMillis()
        val active = Store.tasks(context).filter { it.status == "active" }
        val overdue = active.filter { it.start < now }.sortedByDescending { it.start }
        val groups = active.filter { it.start >= now }.groupBy { it.category }
            .entries.sortedBy { entry -> entry.value.minOf { it.start } }
        val palette = intArrayOf(
            Color.rgb(0, 83, 220), Color.rgb(0, 115, 58),
            Color.rgb(115, 43, 170), Color.rgb(170, 87, 0),
            Color.rgb(0, 105, 120), Color.rgb(130, 45, 83)
        )
        val openApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val widget = RemoteViews(context.packageName, R.layout.widget)
            widget.removeAllViews(R.id.widget_rows)
            widget.setOnClickPendingIntent(R.id.widget_title, openApp)
            fun addGroup(title: String, description: String, color: Int) {
                val row = RemoteViews(context.packageName, R.layout.widget_group)
                row.setTextViewText(R.id.group_heading, title)
                row.setTextViewText(R.id.group_task, description)
                row.setTextColor(R.id.group_heading, color)
                row.setTextColor(R.id.group_task, color)
                row.setOnClickPendingIntent(R.id.group_heading, openApp)
                row.setOnClickPendingIntent(R.id.group_task, openApp)
                widget.addView(R.id.widget_rows, row)
            }
            if (overdue.isNotEmpty()) {
                val latest = overdue.first()
                addGroup("🔴 অতিবাহিত (${overdue.size})",
                    "${latest.name} • ${Store.countdown(latest.start - now)}", Color.rgb(175, 35, 45))
            }
            groups.forEachIndexed { index, group ->
                val nearest = group.value.minBy { it.start }
                val color = palette[index % palette.size]
                addGroup("● ${group.key} (${group.value.size})",
                    "${nearest.name} • ${Store.countdown(nearest.start - now)}", color)
            }
            if (overdue.isEmpty() && groups.isEmpty()) {
                addGroup("কোনো সক্রিয় টাস্ক নেই", "নতুন টাস্ক যোগ করতে ট্যাপ করুন", Color.rgb(15, 45, 105))
            }
            manager.updateAppWidget(id, widget)
        }
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TaskWidget::class.java))
            if (ids.isNotEmpty()) TaskWidget().onUpdate(context, manager, ids)
        }
    }
}
