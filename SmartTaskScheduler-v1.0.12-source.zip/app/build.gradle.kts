plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.rangdhanu.scheduler"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.rangdhanu.scheduler"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.0.12"
    }
    signingConfigs {
        create("stableRelease") {
            val keyFile = System.getenv("STS_KEYSTORE_FILE")
            if (!keyFile.isNullOrBlank()) {
                storeFile = file(keyFile)
                storePassword = System.getenv("STS_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("STS_KEY_ALIAS")
                keyPassword = System.getenv("STS_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (!System.getenv("STS_KEYSTORE_FILE").isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("stableRelease")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
