package com.rangdhanu.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Refresh the home widget when the next task starts or ends. */
class TaskBoundaryReceiver:BroadcastReceiver() {
 override fun onReceive(context:Context,intent:Intent) {
  TaskWidget.refresh(context)
  scheduleNext(context)
 }
 companion object {
  fun scheduleNext(context:Context) {
   val alarm=context.getSystemService(AlarmManager::class.java)
   val pi=PendingIntent.getBroadcast(context,987654321,Intent(context,TaskBoundaryReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   alarm.cancel(pi)
   val now=System.currentTimeMillis()
   val next=Store.tasks(context).asSequence().filter{it.status=="active"}
    .flatMap{sequenceOf(it.start,Store.endTime(it))}.filter{it>now}.minOrNull() ?: return
   // Inexact while-idle alarm: may be delayed by battery optimizations.
   alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi)
  }
 }
}
