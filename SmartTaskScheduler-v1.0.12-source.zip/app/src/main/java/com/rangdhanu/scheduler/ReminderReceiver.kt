package com.rangdhanu.scheduler
import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){val id=i.getLongExtra("id",-1);val t=Store.tasks(c).firstOrNull {it.id==id&&it.status=="active"}?:return
  val manager=c.getSystemService(NotificationManager::class.java);manager.createNotificationChannel(NotificationChannel("task","Task reminders",NotificationManager.IMPORTANCE_HIGH))
  val launch=PendingIntent.getActivity(c,id.toInt(),Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val note=Notification.Builder(c,"task").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(t.name).setContentText("টাস্ক শুরু হতে ${t.remind} মিনিট বাকি").setAutoCancel(true).setContentIntent(launch).build()
  try{manager.notify(id.toInt(),note)}catch(_:SecurityException){}
 }
 companion object {fun scheduleAll(c:Context){val a=c.getSystemService(AlarmManager::class.java);Store.tasks(c).forEach {t->val pi=PendingIntent.getBroadcast(c,t.id.toInt(),Intent(c,ReminderReceiver::class.java).putExtra("id",t.id),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);a.cancel(pi);val at=t.start-t.remind*60000L;if(t.status=="active"&&t.remind>=0&&at>System.currentTimeMillis()) {try{a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)}catch(_:SecurityException){a.set(AlarmManager.RTC_WAKEUP,at,pi)}}}}}
}
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){ReminderReceiver.scheduleAll(c);TaskWidget.refresh(c);TaskBoundaryReceiver.scheduleNext(c)}}
