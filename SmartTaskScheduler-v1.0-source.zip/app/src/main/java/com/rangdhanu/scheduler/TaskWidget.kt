package com.rangdhanu.scheduler
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.widget.RemoteViews

class TaskWidget:AppWidgetProvider(){
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ids.forEach {id->val v=RemoteViews(c.packageName,R.layout.widget);val now=System.currentTimeMillis();val tasks=Store.tasks(c).filter{it.status=="active"};val overdue=tasks.filter{it.start<now}.sortedByDescending{it.start};val future=tasks.filter{it.start>=now};val groups=future.groupBy{it.category}.entries.sortedBy{e->e.value.minOf{it.start}};val lines=mutableListOf<String>();if(overdue.isNotEmpty()){lines.add("🔴 অতিবাহিত (${overdue.size})");overdue.take(2).forEach{lines.add("  ${it.name}: ${Store.countdown(it.start-now)}")}}
  val marks=listOf("🔵","🟢","🟣","🟠","⚪");groups.forEachIndexed {idx,e->val nearest=e.value.minBy{it.start};lines.add("${marks[idx%marks.size]} ${e.key} (${e.value.size})");lines.add("  ${nearest.name} • ${Store.countdown(nearest.start-now)}")};v.setTextViewText(R.id.widget_items,if(lines.isEmpty())"কোনো সক্রিয় টাস্ক নেই" else lines.joinToString("\n"));val pi=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_title,pi);v.setOnClickPendingIntent(R.id.widget_items,pi);m.updateAppWidget(id,v)}
 }
 companion object{fun refresh(c:Context){val m=AppWidgetManager.getInstance(c);val ids=m.getAppWidgetIds(ComponentName(c,TaskWidget::class.java));if(ids.isNotEmpty())TaskWidget().onUpdate(c,m,ids)}}
}
