package com.rangdhanu.scheduler
import android.Manifest
import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:Activity(){
 private lateinit var root:LinearLayout
 private val handler=Handler(Looper.getMainLooper())
 private val tick=object:Runnable{override fun run(){render();handler.postDelayed(this,1000)}}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),9);render()}
 override fun onResume(){super.onResume();handler.post(tick)}
 override fun onPause(){handler.removeCallbacks(tick);super.onPause()}
 private fun text(s:String,size:Float=16f,bold:Boolean=false):TextView=TextView(this).apply{this.text=s;textSize=size;setTextColor(Color.rgb(28,40,68));setPadding(12,9,12,9);if(bold)setTypeface(null,1)}
 private fun button(s:String,act:()->Unit):Button=Button(this).apply{text=s;setOnClickListener{act()}}
 private fun render(){if(isFinishing)return;val scroll=ScrollView(this);root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,20,16,20);setBackgroundColor(Color.rgb(246,248,255))};scroll.addView(root);setContentView(scroll)
  root.addView(text("Smart Task Scheduler",23f,true));root.addView(button("＋ নতুন টাস্ক",{addTask()}));root.addView(button("ক্যাটাগরি ম্যানেজার",{categories()}));val now=System.currentTimeMillis();val active=Store.tasks(this).filter{it.status=="active"};val overdue=active.filter{it.start<now}.sortedByDescending{it.start};val future=active.filter{it.start>=now};if(overdue.isNotEmpty())section("🔴 অতিবাহিত (${overdue.size})",overdue,true)
  val colors=listOf("🔵","🟢","🟣","🟠","⚪");future.groupBy{it.category}.entries.sortedBy{it.value.minOf{t->t.start}}.forEachIndexed {i,e->section("${colors[i%colors.size]} ${e.key} (${e.value.size})",e.value.sortedBy{it.start},false)}
  if(active.isEmpty())root.addView(text("কোনো সক্রিয় টাস্ক নেই"));root.addView(button("সম্পন্ন টাস্কের ইতিহাস",{history()}))
 }
 private fun section(label:String,tasks:List<Task>,overdue:Boolean){val title=button(label+"  ▾"){};root.addView(title);val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(content);var expanded=overdue;fun populate(){content.removeAllViews();(if(expanded)tasks else tasks.take(1)).forEach{t->val line=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,4,10,8)};line.addView(text("${t.name}  •  ${Store.countdown(t.start-System.currentTimeMillis())}",16f,true));line.addView(text("${SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(t.start))}  |  ${listOf("Low","Medium","High")[t.priority]}",12f));line.setOnClickListener{actions(t)};content.addView(line)}};title.setOnClickListener{expanded=!expanded;populate()};populate()}
 private fun addTask(existing:Task?=null){val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,8,22,0)};val name=EditText(this).apply{hint="টাস্কের নাম";setText(existing?.name?:"")};wrap.addView(name)
  val cats=Store.categories(this);if(cats.isEmpty()){Toast.makeText(this,"প্রথমে ক্যাটাগরি যোগ করুন",Toast.LENGTH_LONG).show();return};val spin=Spinner(this);spin.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats);spin.setSelection(cats.indexOf(existing?.category).coerceAtLeast(0));wrap.addView(spin)
  val priorities=Spinner(this);priorities.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Low","Medium","High"));priorities.setSelection(existing?.priority?:1);wrap.addView(priorities)
  val repeats=listOf("none","daily","weekly","monthly");val repeat=Spinner(this);repeat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("পুনরাবৃত্তি নেই","প্রতিদিন","প্রতি সপ্তাহে","প্রতি মাসে"));repeat.setSelection(repeats.indexOf(existing?.repeat?:"none").coerceAtLeast(0));wrap.addView(repeat)
  val reminder=EditText(this).apply{hint="কত মিনিট আগে রিমাইন্ডার?";inputType=2;setText((existing?.remind?:10).toString())};wrap.addView(reminder)
  val duration=EditText(this).apply{hint="কাজের সময়কাল (মিনিট)";inputType=2;setText((existing?.duration?:60).toString())};wrap.addView(duration)
  val cal=Calendar.getInstance().apply{timeInMillis=existing?.start?:System.currentTimeMillis()+3600000};val whenButton=button("সময়: ${SimpleDateFormat("dd MMM yyyy hh:mm a",Locale.getDefault()).format(cal.time)}"){};wrap.addView(whenButton)
  whenButton.setOnClickListener{DatePickerDialog(this,{_,y,m,d->cal.set(y,m,d);TimePickerDialog(this,{_,h,min->cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,min);cal.set(Calendar.SECOND,0);whenButton.text="সময়: ${SimpleDateFormat("dd MMM yyyy hh:mm a",Locale.getDefault()).format(cal.time)}"},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show()},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE)).show()}
  AlertDialog.Builder(this).setTitle(if(existing==null)"নতুন টাস্ক" else "টাস্ক পরিবর্তন").setView(wrap).setPositiveButton("সংরক্ষণ"){_,_->if(name.text.toString().isBlank())return@setPositiveButton;val list=Store.tasks(this);if(existing!=null)list.removeAll{it.id==existing.id};list.add(Task(existing?.id?:System.currentTimeMillis(),name.text.toString(),cats[spin.selectedItemPosition],cal.timeInMillis,duration.text.toString().toIntOrNull()?:60,priorities.selectedItemPosition,repeats[repeat.selectedItemPosition],reminder.text.toString().toIntOrNull()?:10));Store.save(this,list);render()}.setNegativeButton("বাতিল",null).show()
 }
 private fun actions(t: Task) {
  val options = arrayOf("সম্পন্ন", "সময় পরিবর্তন / সম্পাদনা", "আর্কাইভ", "ডিলিট")
  AlertDialog.Builder(this).setTitle(t.name).setItems(options) { _, choice ->
   when (choice) {
    0 -> {
     val all = Store.tasks(this)
     all.replaceAll { if (it.id == t.id) Store.next(it) else it }
     Store.save(this, all)
     render()
    }
    1 -> addTask(t)
    2 -> {
     val all = Store.tasks(this)
     all.replaceAll { if (it.id == t.id) it.copy(status = "archived") else it }
     Store.save(this, all)
     render()
    }
    3 -> AlertDialog.Builder(this)
     .setMessage("এই টাস্ক স্থায়ীভাবে ডিলিট করবেন?")
     .setPositiveButton("ডিলিট") { _, _ ->
      Store.save(this, Store.tasks(this).filter { it.id != t.id })
      render()
     }
     .setNegativeButton("বাতিল", null)
     .show()
   }
  }.show()
 }
 private fun categories(){val items=Store.categories(this);val input=EditText(this).apply{hint="নতুন ক্যাটাগরি"};val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(input)};AlertDialog.Builder(this).setTitle("ক্যাটাগরি ম্যানেজার").setView(panel).setPositiveButton("যোগ করুন"){_,_->val v=input.text.toString().trim();if(v.isNotBlank()&&!items.contains(v)){items.add(v);Store.saveCategories(this,items)};render()}.setNeutralButton("ক্যাটাগরি তালিকা"){_,_->AlertDialog.Builder(this).setItems(items.toTypedArray()){_,idx->val old=items[idx];val edit=EditText(this).apply{setText(old)};AlertDialog.Builder(this).setTitle("নাম পরিবর্তন: $old").setView(edit).setPositiveButton("পরিবর্তন"){_,_->val new=edit.text.toString().trim();if(new.isNotEmpty()&&!items.contains(new)){items[idx]=new;Store.saveCategories(this,items);Store.save(this,Store.tasks(this).map{if(it.category==old)it.copy(category=new)else it})}}.setNegativeButton("বাতিল",null).show()}.show()}.setNegativeButton("বাতিল",null).show()}
 private fun history(){val list=Store.tasks(this).filter{it.status!="active"};AlertDialog.Builder(this).setTitle("History / Archive").setMessage(if(list.isEmpty())"কোনো রেকর্ড নেই" else list.joinToString("\n"){"${it.name} — ${it.status}"}).setPositiveButton("ঠিক আছে",null).show()}
}
