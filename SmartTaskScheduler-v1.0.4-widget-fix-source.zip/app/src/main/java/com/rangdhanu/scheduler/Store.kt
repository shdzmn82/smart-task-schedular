package com.rangdhanu.scheduler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class Task(val id:Long,val name:String,val category:String,val start:Long,val duration:Int,val priority:Int,val repeat:String,val remind:Int,val status:String="active")
object Store {
 val defaults=listOf("শিক্ষাদান","কোচিং","প্রশ্ন প্রণয়ন","প্রশাসনিক","ব্যক্তিগত")
 fun categories(c:Context):MutableList<String> { val s=c.getSharedPreferences("tasks",0).getString("cats",null) ?: return defaults.toMutableList(); val a=JSONArray(s);return (0 until a.length()).map { a.getString(it) }.toMutableList() }
 fun saveCategories(c:Context,v:List<String>){c.getSharedPreferences("tasks",0).edit().putString("cats",JSONArray(v).toString()).apply()}
 fun tasks(c:Context):MutableList<Task> { val a=JSONArray(c.getSharedPreferences("tasks",0).getString("items","[]"));return (0 until a.length()).map { val o=a.getJSONObject(it);Task(o.getLong("id"),o.getString("name"),o.getString("category"),o.getLong("start"),o.optInt("duration",60),o.optInt("priority",1),o.optString("repeat","none"),o.optInt("remind",10),o.optString("status","active")) }.toMutableList() }
 fun save(c:Context,v:List<Task>){val a=JSONArray();v.forEach {t-> a.put(JSONObject().put("id",t.id).put("name",t.name).put("category",t.category).put("start",t.start).put("duration",t.duration).put("priority",t.priority).put("repeat",t.repeat).put("remind",t.remind).put("status",t.status)) };c.getSharedPreferences("tasks",0).edit().putString("items",a.toString()).apply();TaskWidget.refresh(c);ReminderReceiver.scheduleAll(c)}
 fun next(t:Task):Task { val cal=Calendar.getInstance();cal.timeInMillis=t.start;when(t.repeat){"daily"->cal.add(Calendar.DATE,1);"weekly"->cal.add(Calendar.DATE,7);"monthly"->cal.add(Calendar.MONTH,1);else->return t.copy(status="done")};return t.copy(start=cal.timeInMillis,status="active") }
 fun countdown(ms:Long):String {val n=kotlin.math.abs(ms);val s=n/1000;val d=TimeUnit.MILLISECONDS.toDays(n);val months=d/30;val years=d/365;val text=when {years>=1->"${years} বছর";months>=1->"${months} মাস";d>=1->"${d} দিন";s>=3600->"${s/3600} ঘণ্টা";s>=60->"${s/60} মিনিট";else->"${s} সেকেন্ড"};return if(ms<0)"$text আগে" else text }
}
