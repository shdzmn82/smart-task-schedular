plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.rangdhanu.scheduler"; compileSdk = 35
 defaultConfig { applicationId = "com.rangdhanu.scheduler"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "1.0.3" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
