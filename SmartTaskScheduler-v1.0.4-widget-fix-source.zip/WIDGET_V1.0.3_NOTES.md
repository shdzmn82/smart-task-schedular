# Widget v1.0.3
- Tap a category header to expand/collapse its task list.
- Expansion is saved separately for each home-screen widget instance.
- Only upcoming tasks count toward each category heading.
- Overdue tasks remain at top; no automatic deletion.
- Category colors stay stable as group order changes.
- Uses one-unit countdown. Widget refreshes on standard Android widget refresh schedule or when tasks are saved; this is not a second-by-second live widget.
- Large expanded lists may be clipped by the Android launcher widget bounds. Resize the widget to see more rows.
- Build has not been executed locally; use GitHub Actions to verify compilation.
