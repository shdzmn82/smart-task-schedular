# Widget v1.0.4

- Background white opacity: 50% (`#80FFFFFF`).
- Group expansion toggles only on header taps; tapping task text opens the app.
- Expansion preference committed synchronously before refresh.
- Duplicate taps within 800 ms are ignored to avoid immediate collapse on launchers that dispatch a click twice.
- Color palette and future-only counts unchanged.
- Android build/device validation pending.
