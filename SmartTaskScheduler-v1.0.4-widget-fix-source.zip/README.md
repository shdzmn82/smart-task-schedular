# Smart Task Scheduler v1.0 (Android)

বাংলা Android task scheduler. Offline JSON-backed local storage, categories, countdown, overdue-first ordering, manual-only delete, task completion, rescheduling, archive, repeat daily/weekly/monthly, priority, notification reminders and home screen widget.

## GitHub mobile build
1. Create an **empty** GitHub repository.
2. Upload **the contents of this ZIP** into the repository root (the `.github/workflows/android.yml` file must be included).
3. Open **Actions → Build Android APK → Run workflow** (or push to main).
4. After successful build, open workflow run → **Artifacts → SmartTaskScheduler-v1-debug-apk**. Download and extract the artifact ZIP, then install `app-debug.apk`.
5. Add widget from Android home screen → Widgets → Smart Task Scheduler.

## Notes / current limitations
- This is a source release, not a precompiled APK; build has not been executed in this environment.
- Widget is a compact summary; tapping it opens the app for expansion and editing. Android periodically updates widget (normally at least 30 minutes); second-by-second countdown runs in the app, not the widget.
- Widget group colors are currently colored emoji markers rather than fully colored group cards.
- Category rename/add works; category deletion and per-category custom color picker are deferred.
- Repeat completion advances the recurring occurrence; completed one-time tasks are stored in history.
- Notifications may require Android notification permission and are subject to Android battery restrictions.
- Data is private app storage and is removed on uninstall. No backup/export yet.
- For monthly countdown the compact unit uses 30-day approximation; calendar-accurate months are a future refinement.
- Widget cannot directly mark complete; open the app to do so.
