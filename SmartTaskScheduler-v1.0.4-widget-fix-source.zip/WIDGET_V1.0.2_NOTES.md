# Smart Scheduler widget v1.0.2
- Background: white at 25% opacity (`#40FFFFFF`), rounded corners.
- Header: bold 21sp; task line: 18sp; title: 23sp.
- Each category uses a distinct text color; overdue red.
- Groups are sorted by nearest future task; overdue is always first.
- Group counts include future active tasks only.
- The nearest task is visible for each group.
- Android home-screen widgets may refresh less frequently than the in-app countdown.
- Existing data is preserved when updating the same application ID.
- Not yet compiled on GitHub; run workflow and inspect APK before release.
