package com.rangdhanu.scheduler

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class Task(val id:Long,val name:String,val category:String,val start:Long,val duration:Int,val priority:Int,val repeat:String,val remind:Int,val status:String="active")
object Store {
 val defaults=listOf("শিক্ষাদান","কোচিং","প্রশ্ন প্রণয়ন","প্রশাসনিক","ব্যক্তিগত")
 fun categories(c:Context):MutableList<String> { val s=c.getSharedPreferences("tasks",0).getString("cats",null) ?: return defaults.toMutableList(); val a=JSONArray(s);return (0 until a.length()).map { a.getString(it) }.toMutableList() }
 fun saveCategories(c:Context,v:List<String>){c.getSharedPreferences("tasks",0).edit().putString("cats",JSONArray(v).toString()).apply()}
 fun tasks(c:Context):MutableList<Task> { val a=JSONArray(c.getSharedPreferences("tasks",0).getString("items","[]"));return (0 until a.length()).map { val o=a.getJSONObject(it);Task(o.getLong("id"),o.getString("name"),o.getString("category"),o.getLong("start"),o.optInt("duration",60),o.optInt("priority",1),o.optString("repeat","none"),o.optInt("remind",10),o.optString("status","active")) }.toMutableList() }
 fun save(c:Context,v:List<Task>){val a=JSONArray();v.forEach {t-> a.put(JSONObject().put("id",t.id).put("name",t.name).put("category",t.category).put("start",t.start).put("duration",t.duration).put("priority",t.priority).put("repeat",t.repeat).put("remind",t.remind).put("status",t.status)) };c.getSharedPreferences("tasks",0).edit().putString("items",a.toString()).apply();TaskWidget.refresh(c);ReminderReceiver.scheduleAll(c);TaskBoundaryReceiver.scheduleNext(c)}
 // Weekly multi-day schedule: days:1,3,4 (Calendar.SUNDAY, TUESDAY, WEDNESDAY).
 val dayNames = listOf("রবি","সোম","মঙ্গল","বুধ","বৃহস্পতি","শুক্র","শনি")
 fun selectedDays(repeat:String):Set<Int> =
  if (!repeat.startsWith("days:")) emptySet()
  else repeat.removePrefix("days:").split(",").mapNotNull { it.toIntOrNull() }
   .filter { it in 1..7 }.toSet()
 fun priorityColor(p:Int):Int=when(p){2->Color.rgb(190,35,45);1->Color.rgb(186,105,0);else->Color.rgb(17,132,69)}
 fun repeatColor(r:String):Int=when {
  r.startsWith("days:")->Color.rgb(190,40,120)
  r.startsWith("interval:")->Color.rgb(0,130,120)
  else->when(r){"daily"->Color.rgb(30,95,205);"weekly"->Color.rgb(116,55,185);"monthly"->Color.rgb(0,125,160);"yearly"->Color.rgb(157,95,0);else->Color.rgb(95,110,130)}
 }
 fun repeatLabel(repeat:String):String =
  if(repeat.startsWith("days:")) selectedDays(repeat).sorted().joinToString(", ") { dayNames[it-1] }
  else if(repeat.startsWith("interval:")) "প্রতি ${repeat.removePrefix("interval:")} দিন"
  else when(repeat){"daily"->"প্রতিদিন";"weekly"->"প্রতি সপ্তাহে";"monthly"->"প্রতি মাসে";else->"একবার"}
 fun firstSelectedTime(start:Long, days:Set<Int>):Long {
  if(days.isEmpty()) return start
  val cal=Calendar.getInstance().apply{timeInMillis=start}
  repeat(7) {
   if(cal.get(Calendar.DAY_OF_WEEK) in days) return cal.timeInMillis
   cal.add(Calendar.DATE,1)
  }
  return start
 }
 fun intervalDays(repeat:String):Int? = if(repeat.startsWith("interval:"))
  repeat.removePrefix("interval:").toIntOrNull()?.takeIf { it in 1..36500 } else null
 fun next(t:Task):Task { val cal=Calendar.getInstance();cal.timeInMillis=t.start;
  if(t.repeat.startsWith("interval:")) {
   val days=intervalDays(t.repeat) ?: return t.copy(status="done")
   cal.add(Calendar.DAY_OF_YEAR,days)
   return t.copy(start=cal.timeInMillis,status="active")
  }
if(t.repeat.startsWith("days:")){
  val days=selectedDays(t.repeat)
  if(days.isEmpty()) return t.copy(status="done")
  // Preserve the selected clock time; advance to the next selected weekday.
  repeat(7) {
   cal.add(Calendar.DATE,1)
   if(cal.get(Calendar.DAY_OF_WEEK) in days) return t.copy(start=cal.timeInMillis,status="active")
  }
  return t.copy(status="done")
 }
 when(t.repeat){"daily"->cal.add(Calendar.DATE,1);"weekly"->cal.add(Calendar.DATE,7);"monthly"->cal.add(Calendar.MONTH,1);else->return t.copy(status="done")};return t.copy(start=cal.timeInMillis,status="active") }
 // End time is exclusive: a task is overdue at exactly start + duration.
 fun endTime(t:Task):Long = t.start + t.duration.coerceAtLeast(1).toLong()*60_000L
 fun isOverdue(t:Task, now:Long):Boolean = now >= endTime(t)
 fun isRunning(t:Task, now:Long):Boolean = now >= t.start && !isOverdue(t,now)
 fun statusText(t:Task,now:Long):String = when {
  isOverdue(t,now) -> "${countdown(now-endTime(t)).removeSuffix(" আগে")} অতিবাহিত"
  isRunning(t,now) -> "${countdown(now-t.start).removeSuffix(" আগে")} ধরে চলমান"
  else -> countdown(t.start-now)
 }
 fun countdown(ms:Long):String {val n=kotlin.math.abs(ms);val s=n/1000;val d=TimeUnit.MILLISECONDS.toDays(n);val months=d/30;val years=d/365;val text=when {years>=1->"${years} বছর";months>=1->"${months} মাস";d>=1->"${d} দিন";s>=3600->"${s/3600} ঘণ্টা";s>=60->"${s/60} মিনিট";else->"${s} সেকেন্ড"};return if(ms<0)"$text আগে" else text }
}
