package com.rangdhanu.scheduler
import android.Manifest
import android.net.Uri
import java.io.IOException
import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:Activity(){
 private val createBackupRequest = 3101
 private val restoreBackupRequest = 3102
 override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(resultCode!=RESULT_OK) return
  val uri=data?.data ?: return
  when(requestCode){
   createBackupRequest -> try {
    val output=contentResolver.openOutputStream(uri,"wt") ?: throw IOException("Cannot open backup destination")
    output.bufferedWriter(Charsets.UTF_8).use { it.write(BackupManager.export(this)) }
    Toast.makeText(this,"ব্যাকআপ সংরক্ষিত হয়েছে",Toast.LENGTH_LONG).show()
   } catch(e:Exception){showBackupError(e)}
   restoreBackupRequest -> try {
    val input=contentResolver.openInputStream(uri) ?: throw IOException("Cannot open backup file")
    val raw=input.bufferedReader(Charsets.UTF_8).use { reader ->
     val result=StringBuilder();val buf=CharArray(8192)
     while(true){val n=reader.read(buf);if(n<0)break;result.append(buf,0,n);if(result.length>10_000_000)throw IOException("Backup too large")}
     result.toString()
    }
    AlertDialog.Builder(this).setTitle("Restore নিশ্চিত করুন")
     .setMessage("বর্তমান টাস্ক ও ক্যাটাগরি মুছে ব্যাকআপের তথ্য বসবে। আগে বর্তমান তথ্যের ব্যাকআপ রাখুন।")
     .setPositiveButton("Restore"){_,_->try {val count=BackupManager.restoreWithSafetyCopy(this,raw);Toast.makeText(this,"$count টি টাস্ক Restore হয়েছে",Toast.LENGTH_LONG).show();render()}catch(e:Exception){showBackupError(e)}}
     .setNegativeButton("বাতিল",null).show()
   }catch(e:Exception){showBackupError(e)}
  }
 }
 private fun showBackupError(e:Exception){AlertDialog.Builder(this).setTitle("Backup / Restore সমস্যা").setMessage(e.message?:"Unknown error").setPositiveButton("ঠিক আছে",null).show()}
 private fun recoverPreviousData(){
  val backup=BackupManager.safetyCopy(this)
  if(backup==null){Toast.makeText(this,"কোনো আগের Restore-এর কপি নেই",Toast.LENGTH_LONG).show();return}
  AlertDialog.Builder(this).setTitle("আগের তথ্য ফিরিয়ে আনবেন?")
   .setMessage("সর্বশেষ Restore-এর আগের টাস্ক ও ক্যাটাগরি ফিরে আসবে। বর্তমান তথ্যও সুরক্ষিত থাকবে।")
   .setPositiveButton("ফিরিয়ে আনুন"){_,_->try{val count=BackupManager.restoreWithSafetyCopy(this,backup);Toast.makeText(this,"$count টি টাস্ক ফিরেছে",Toast.LENGTH_LONG).show();render()}catch(e:Exception){showBackupError(e)}}
   .setNegativeButton("বাতিল",null).show()
 }
 private fun backupToDrive(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"SmartTaskScheduler-backup-${System.currentTimeMillis()}.json")},createBackupRequest)}
 private fun restoreFromDrive(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},restoreBackupRequest)}

 private lateinit var root:LinearLayout
 private var expandedGroup:String?=null
 private val liveStatuses=mutableListOf<Pair<TextView,Task>>()
 private val handler=Handler(Looper.getMainLooper())
 private val tick=object:Runnable{override fun run(){
  val now=System.currentTimeMillis()
  liveStatuses.forEach { (view,task) ->
   view.text="${task.name}  •  ${Store.statusText(task,now)}"
  }
  handler.postDelayed(this,1000)
 }}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),9);render()}
 override fun onResume(){super.onResume();handler.post(tick)}
 override fun onPause(){handler.removeCallbacks(tick);super.onPause()}
 private fun text(s:String,size:Float=16f,bold:Boolean=false):TextView=TextView(this).apply{this.text=s;textSize=size;setTextColor(Color.rgb(28,40,68));setPadding(12,9,12,9);if(bold)setTypeface(null,1)}
 private fun button(s:String,act:()->Unit):Button=Button(this).apply{text=s;setOnClickListener{act()}}
 private fun render(){
  if(isFinishing)return
  liveStatuses.clear()
  val scroll=ScrollView(this).apply{isFillViewport=true}
  root=LinearLayout(this).apply{
   orientation=LinearLayout.VERTICAL
   setPadding(16,20,16,20)
   setBackgroundColor(Color.rgb(246,248,255))
  }
  scroll.addView(root)
  setContentView(scroll)
  root.addView(text("Smart Task Scheduler",23f,true))
  root.addView(button("＋ নতুন টাস্ক",{addTask()}))
  root.addView(button("ক্যাটাগরি ম্যানেজার",{categories()}))
  root.addView(button("Google Drive / ফাইলে Backup",{backupToDrive()}))
  root.addView(button("Google Drive / ফাইল থেকে Restore",{restoreFromDrive()}))
  root.addView(button("আগের Restore-এর তথ্য ফিরিয়ে আনুন",{recoverPreviousData()}))
  val now=System.currentTimeMillis()
  val active=Store.tasks(this).filter{it.status=="active"}
  val overdue=active.filter{Store.isOverdue(it,now)}.sortedBy{Store.endTime(it)}
  val future=active.filter{!Store.isOverdue(it,now)}
  val sections=mutableListOf<Pair<String,List<Task>>>()
  if(overdue.isNotEmpty())sections.add("🔴 অতিবাহিত (${overdue.size})" to overdue)
  val colors=listOf("🔵","🟢","🟣","🟠","⚪")
  future.groupBy{it.category}.entries.sortedBy{it.value.minOf{t->t.start}}.forEachIndexed {i,e->
   sections.add("${colors[i%colors.size]} ${e.key} (${e.value.size})" to e.value.sortedBy{it.start})
  }
  // If a category disappeared after editing, no group remains expanded.
  if(sections.none{it.first==expandedGroup})expandedGroup=null
  val headers=mutableMapOf<String,Button>()
  val bodies=mutableMapOf<String,LinearLayout>()
  sections.forEach { (label,tasks) ->
   val title=button(""){}
   val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
   root.addView(title)
   root.addView(content)
   headers[label]=title
   bodies[label]=content
   fun draw(){
    val expanded=expandedGroup==label
    title.text=label+(if(expanded)"  ▴" else "  ▾")
    content.removeAllViews()
    val shown=if(expanded)tasks else tasks.take(1)
    shown.forEach {t->
     val line=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,4,10,8)}
     val status=text("${t.name}  •  ${Store.statusText(t,System.currentTimeMillis())}",16f,true)
     liveStatuses.add(status to t)
     line.addView(status)
     line.addView(text("${SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(t.start))}  |  ${Store.repeatLabel(t.repeat)}  |  ${listOf("Low","Medium","High")[t.priority]}",12f))
     line.setOnClickListener{actions(t)}
     content.addView(line)
    }
   }
   title.setOnClickListener{
    expandedGroup=if(expandedGroup==label)null else label
    // Repaint all accordion groups without replacing the ScrollView.
    liveStatuses.clear()
    sections.forEach { (otherLabel,otherTasks) ->
     val otherTitle=headers[otherLabel]?:return@forEach
     val otherContent=bodies[otherLabel]?:return@forEach
     val expanded=expandedGroup==otherLabel
     otherTitle.text=otherLabel+(if(expanded)"  ▴" else "  ▾")
     otherContent.removeAllViews()
     (if(expanded)otherTasks else otherTasks.take(1)).forEach {t->
      val line=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,4,10,8)}
      val status=text("${t.name}  •  ${Store.statusText(t,System.currentTimeMillis())}",16f,true)
      liveStatuses.add(status to t)
      line.addView(status)
      line.addView(text("${SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(t.start))}  |  ${Store.repeatLabel(t.repeat)}  |  ${listOf("Low","Medium","High")[t.priority]}",12f))
      line.setOnClickListener{actions(t)}
      otherContent.addView(line)
     }
    }
   }
   draw()
  }
  if(active.isEmpty())root.addView(text("কোনো সক্রিয় টাস্ক নেই"))
  root.addView(button("সম্পন্ন টাস্কের ইতিহাস",{history()}))
 }
 private fun addTask(existing:Task?=null){val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,8,22,0)};val name=EditText(this).apply{hint="টাস্কের নাম";setText(existing?.name?:"")};wrap.addView(name)
  val cats=Store.categories(this);if(cats.isEmpty()){Toast.makeText(this,"প্রথমে ক্যাটাগরি যোগ করুন",Toast.LENGTH_LONG).show();return};val spin=Spinner(this);spin.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats);spin.setSelection(cats.indexOf(existing?.category).coerceAtLeast(0));wrap.addView(spin)
  val priorities=Spinner(this);priorities.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Low","Medium","High"));priorities.setSelection(existing?.priority?:1);wrap.addView(priorities)
  val repeats=listOf("none","daily","weekly","monthly","days","interval");val repeat=Spinner(this);repeat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("পুনরাবৃত্তি নেই","প্রতিদিন","প্রতি সপ্তাহে","প্রতি মাসে","সপ্তাহের নির্দিষ্ট দিন","নির্দিষ্ট দিন অন্তর"));repeat.setSelection(if(existing?.repeat?.startsWith("days:")==true)4 else if(existing?.repeat?.startsWith("interval:")==true)5 else repeats.indexOf(existing?.repeat?:"none").coerceAtLeast(0));wrap.addView(repeat)
  val dayPanel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  dayPanel.addView(text("যেসব দিনে টাস্কটি হবে (একাধিক নির্বাচন করুন)",14f,true))
  val dayChecks=(1..7).map { day ->
   CheckBox(this).apply{
    text=Store.dayNames[day-1]
    isChecked=day in Store.selectedDays(existing?.repeat?:"")
    dayPanel.addView(this)
   }
  }
  wrap.addView(dayPanel)
  val intervalPanel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  intervalPanel.addView(text("কত দিন পরপর টাস্কটি হবে? (যেমন ৩৫, ৬০, ৭৫)",14f,true))
  val intervalInput=EditText(this).apply{
   hint="দিনের সংখ্যা (১–৩৬৫০০)";inputType=android.text.InputType.TYPE_CLASS_NUMBER
   setText(Store.intervalDays(existing?.repeat?:"")?.toString()?:"35")
  }
  intervalPanel.addView(intervalInput);wrap.addView(intervalPanel)
  intervalPanel.visibility=if(repeat.selectedItemPosition==5)View.VISIBLE else View.GONE
  dayPanel.visibility=if(repeat.selectedItemPosition==4)View.VISIBLE else View.GONE
  repeat.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
   override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){
    dayPanel.visibility=if(position==4)View.VISIBLE else View.GONE
    intervalPanel.visibility=if(position==5)View.VISIBLE else View.GONE
   }
   override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}
  }
  val reminder=EditText(this).apply{hint="কত মিনিট আগে রিমাইন্ডার?";inputType=2;setText((existing?.remind?:10).toString())};wrap.addView(reminder)
  val duration=EditText(this).apply{hint="কাজের সময়কাল (মিনিট)";inputType=2;setText((existing?.duration?:60).toString())};wrap.addView(duration)
  val cal=Calendar.getInstance().apply{timeInMillis=existing?.start?:System.currentTimeMillis()+3600000};val whenButton=button("সময়: ${SimpleDateFormat("dd MMM yyyy hh:mm a",Locale.getDefault()).format(cal.time)}"){};wrap.addView(whenButton)
  whenButton.setOnClickListener{DatePickerDialog(this,{_,y,m,d->cal.set(y,m,d);TimePickerDialog(this,{_,h,min->cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,min);cal.set(Calendar.SECOND,0);whenButton.text="সময়: ${SimpleDateFormat("dd MMM yyyy hh:mm a",Locale.getDefault()).format(cal.time)}"},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show()},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DATE)).show()}
  val dialog=AlertDialog.Builder(this).setTitle(if(existing==null)"নতুন টাস্ক" else "টাস্ক পরিবর্তন").setView(ScrollView(this).apply{addView(wrap)})
   .setPositiveButton("সংরক্ষণ",null).setNegativeButton("বাতিল",null).create()
  dialog.setOnShowListener{
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
    if(name.text.toString().isBlank()){name.error="টাস্কের নাম লিখুন";return@setOnClickListener}
    val days=dayChecks.mapIndexedNotNull { idx,check -> if(check.isChecked)idx+1 else null }.toSet()
    val selectedRepeat=when(repeat.selectedItemPosition){
     4 -> {
      if(days.isEmpty()){Toast.makeText(this,"অন্তত একটি দিন নির্বাচন করুন",Toast.LENGTH_LONG).show();return@setOnClickListener}
      "days:"+days.sorted().joinToString(",")
     }
     5 -> {
      val count=intervalInput.text.toString().trim().toIntOrNull()
      if(count==null || count !in 1..36500){intervalInput.error="১ থেকে ৩৬৫০০ দিনের মধ্যে সংখ্যা লিখুন";return@setOnClickListener}
      "interval:$count"
     }
     else -> repeats[repeat.selectedItemPosition]
    }
    val start=if(days.isNotEmpty()&&repeat.selectedItemPosition==4)Store.firstSelectedTime(cal.timeInMillis,days)else cal.timeInMillis
    val list=Store.tasks(this)
    if(existing!=null)list.removeAll{it.id==existing.id}
    list.add(Task(existing?.id?:System.currentTimeMillis(),name.text.toString().trim(),cats[spin.selectedItemPosition],start,(duration.text.toString().toIntOrNull()?:60).coerceIn(1,525600),priorities.selectedItemPosition,selectedRepeat,reminder.text.toString().toIntOrNull()?:10))
    Store.save(this,list);dialog.dismiss();render()
   }
  }
  dialog.show()
 }
 private fun actions(t: Task) {
  val options = arrayOf("সম্পন্ন", "সময় পরিবর্তন / সম্পাদনা", "আর্কাইভ", "ডিলিট")
  AlertDialog.Builder(this).setTitle(t.name).setItems(options) { _, choice ->
   when (choice) {
    0 -> {
     val all = Store.tasks(this)
     all.replaceAll { if (it.id == t.id) Store.next(it) else it }
     Store.save(this, all)
     render()
    }
    1 -> addTask(t)
    2 -> {
     val all = Store.tasks(this)
     all.replaceAll { if (it.id == t.id) it.copy(status = "archived") else it }
     Store.save(this, all)
     render()
    }
    3 -> AlertDialog.Builder(this)
     .setMessage("এই টাস্ক স্থায়ীভাবে ডিলিট করবেন?")
     .setPositiveButton("ডিলিট") { _, _ ->
      Store.save(this, Store.tasks(this).filter { it.id != t.id })
      render()
     }
     .setNegativeButton("বাতিল", null)
     .show()
   }
  }.show()
 }
 private fun categories(){val items=Store.categories(this);val input=EditText(this).apply{hint="নতুন ক্যাটাগরি"};val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(input)};AlertDialog.Builder(this).setTitle("ক্যাটাগরি ম্যানেজার").setView(panel).setPositiveButton("যোগ করুন"){_,_->val v=input.text.toString().trim();if(v.isNotBlank()&&!items.contains(v)){items.add(v);Store.saveCategories(this,items)};render()}.setNeutralButton("ক্যাটাগরি তালিকা"){_,_->AlertDialog.Builder(this).setItems(items.toTypedArray()){_,idx->val old=items[idx];val edit=EditText(this).apply{setText(old)};AlertDialog.Builder(this).setTitle("নাম পরিবর্তন: $old").setView(edit).setPositiveButton("পরিবর্তন"){_,_->val new=edit.text.toString().trim();if(new.isNotEmpty()&&!items.contains(new)){items[idx]=new;Store.saveCategories(this,items);Store.save(this,Store.tasks(this).map{if(it.category==old)it.copy(category=new)else it})}}.setNegativeButton("বাতিল",null).show()}.show()}.setNegativeButton("বাতিল",null).show()}
 private fun history(){val list=Store.tasks(this).filter{it.status!="active"};AlertDialog.Builder(this).setTitle("History / Archive").setMessage(if(list.isEmpty())"কোনো রেকর্ড নেই" else list.joinToString("\n"){"${it.name} — ${it.status}"}).setPositiveButton("ঠিক আছে",null).show()}
}
