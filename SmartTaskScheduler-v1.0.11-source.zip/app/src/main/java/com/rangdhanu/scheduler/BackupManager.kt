package com.rangdhanu.scheduler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Portable, versioned JSON backup. Never stores account credentials. */
object BackupManager {
    fun export(c: Context): String {
        val prefs = c.getSharedPreferences("tasks", Context.MODE_PRIVATE)
        val cats = JSONArray(prefs.getString("cats", JSONArray(Store.categories(c)).toString()))
        val items = JSONArray(prefs.getString("items", "[]"))
        return JSONObject()
            .put("format", "smart-task-scheduler-backup")
            .put("schemaVersion", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("categories", cats)
            .put("tasks", items)
            .toString(2)
    }

    /** Keep one local safety copy before replacing task data. */
    fun safetyCopy(c: Context): String? = c.getSharedPreferences("sts_restore_safety", Context.MODE_PRIVATE)
        .getString("previous", null)

    fun restoreWithSafetyCopy(c: Context, raw: String): Int {
        // Validate incoming backup before touching local data.
        validate(raw)
        val previous = export(c)
        val safetyPrefs = c.getSharedPreferences("sts_restore_safety", Context.MODE_PRIVATE)
        check(safetyPrefs.edit().putString("previous", previous).commit()) { "Could not save safety copy" }
        return restore(c, raw)
    }

    private fun validate(raw: String) {
        val json = JSONObject(raw)
        require(json.optString("format") == "smart-task-scheduler-backup") { "Not a Smart Scheduler backup" }
        require(json.optInt("schemaVersion") == 1) { "Unsupported backup version" }
        require(json.has("categories") && json.has("tasks")) { "Missing backup data" }
    }

    /** Validate fully before writing anything. Returns number of restored tasks. */
    fun restore(c: Context, raw: String): Int {
        validate(raw)
        val json = JSONObject(raw)
        require(json.optString("format") == "smart-task-scheduler-backup") { "Not a Smart Scheduler backup" }
        require(json.optInt("schemaVersion") == 1) { "Unsupported backup version" }
        val cats = json.getJSONArray("categories")
        val tasks = json.getJSONArray("tasks")
        require(cats.length() <= 2000 && tasks.length() <= 50000) { "Backup exceeds supported size" }
        val names = HashSet<String>()
        for (i in 0 until cats.length()) {
            val name = cats.getString(i)
            require(name.isNotBlank() && name.length <= 200 && names.add(name)) { "Invalid category" }
        }
        val ids = HashSet<Long>()
        for (i in 0 until tasks.length()) {
            val t = tasks.getJSONObject(i)
            val id = t.getLong("id")
            require(ids.add(id)) { "Duplicate task ID" }
            require(t.getString("name").isNotBlank() && t.getString("name").length <= 1000) { "Invalid task name" }
            require(names.contains(t.getString("category"))) { "Unknown task category" }
            require(t.getLong("start") > 0) { "Invalid start time" }
            require(t.optInt("duration", 60) >= 0 && t.optInt("remind", 10) >= 0) { "Invalid duration or reminder" }
            require(t.optInt("priority", 1) in 0..2) { "Invalid priority" }
            require(t.optString("repeat", "none") in listOf("none", "daily", "weekly", "monthly")) { "Invalid repeat" }
            require(t.optString("status", "active") in listOf("active", "done", "archived")) { "Invalid status" }
        }
        val ok = c.getSharedPreferences("tasks", Context.MODE_PRIVATE).edit()
            .putString("cats", cats.toString())
            .putString("items", tasks.toString())
            .commit()
        check(ok) { "Could not save restored data" }
        TaskWidget.refresh(c)
        ReminderReceiver.scheduleAll(c)
        return tasks.length()
    }
}
