package com.rangdhanu.scheduler

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class TaskWidget : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            val group = intent.getStringExtra(EXTRA_GROUP) ?: return
            if (widgetId == -1) return
            val prefs = context.getSharedPreferences("widget_expansion", Context.MODE_PRIVATE)
            val key = "${widgetId}_$group"
            // Some launchers deliver duplicate widget clicks in quick succession.
            // Debounce them and persist the new state before redrawing the widget.
            val lastKey = "last_toggle_${widgetId}_$group"
            val now = android.os.SystemClock.elapsedRealtime()
            val last = prefs.getLong(lastKey, 0L)
            if (last > 0L && now >= last && now - last < 800L) return
            prefs.edit()
                .putBoolean(key, !prefs.getBoolean(key, false))
                .putLong(lastKey, now)
                .commit()
            refresh(context)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences("widget_expansion", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        prefs.all.keys.filter { key -> appWidgetIds.any { key.startsWith("${it}_") } }
            .forEach { editor.remove(it) }
        editor.apply()
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val now = System.currentTimeMillis()
        val active = Store.tasks(context).filter { it.status == "active" }
        val overdue = active.filter { it.start < now }.sortedBy { it.start }
        val groups = active.filter { it.start >= now }.groupBy { it.category }
            .entries.sortedBy { it.value.minOf { task -> task.start } }
        val palette = intArrayOf(
            Color.rgb(0, 83, 220), Color.rgb(0, 115, 58),
            Color.rgb(115, 43, 170), Color.rgb(170, 87, 0),
            Color.rgb(0, 105, 120), Color.rgb(130, 45, 83)
        )
        val categories = Store.categories(context)
        val prefs = context.getSharedPreferences("widget_expansion", Context.MODE_PRIVATE)
        val openApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val widget = RemoteViews(context.packageName, R.layout.widget)
            widget.removeAllViews(R.id.widget_rows)
            widget.setOnClickPendingIntent(R.id.widget_title, openApp)

            fun addGroup(groupKey: String, title: String, tasks: List<Task>, color: Int) {
                val expanded = prefs.getBoolean("${id}_$groupKey", false)
                val row = RemoteViews(context.packageName, R.layout.widget_group)
                row.setTextViewText(R.id.group_heading, (if (expanded) "▾ " else "▸ ") + title)
                row.setTextColor(R.id.group_heading, color)
                val toggle = Intent(context, TaskWidget::class.java).apply {
                    action = ACTION_TOGGLE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    putExtra(EXTRA_GROUP, groupKey)
                    data = android.net.Uri.parse("scheduler://toggle/$id/${android.net.Uri.encode(groupKey)}")
                }
                val togglePending = PendingIntent.getBroadcast(
                    context, 0, toggle, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                row.setOnClickPendingIntent(R.id.group_heading, togglePending)
                val visible = if (expanded) tasks else tasks.take(1)
                val taskText = visible.joinToString("\n") { task ->
                    "${task.name} • ${Store.countdown(task.start - now)}"
                }
                row.setTextViewText(R.id.group_task, taskText)
                row.setTextColor(R.id.group_task, color)
                // Only the header toggles expansion, avoiding accidental second taps.
                row.setOnClickPendingIntent(R.id.group_task, openApp)
                // Expanded groups display all tasks; Android may clip if the widget is too short.
                row.setInt(R.id.group_task, "setMaxLines", if (expanded) 50 else 2)
                widget.addView(R.id.widget_rows, row)
            }
            if (overdue.isNotEmpty()) {
                addGroup("__overdue__", "🔴 অতিবাহিত (${overdue.size})", overdue,
                    Color.rgb(175, 35, 45))
            }
            groups.forEach { group ->
                val index = categories.indexOf(group.key).let { if (it >= 0) it else group.key.hashCode().ushr(1) }
                addGroup(group.key, "● ${group.key} (${group.value.size})",
                    group.value.sortedBy { it.start }, palette[index % palette.size])
            }
            if (overdue.isEmpty() && groups.isEmpty()) {
                val row = RemoteViews(context.packageName, R.layout.widget_group)
                row.setTextViewText(R.id.group_heading, "কোনো সক্রিয় টাস্ক নেই")
                row.setTextViewText(R.id.group_task, "নতুন টাস্ক যোগ করতে ট্যাপ করুন")
                row.setOnClickPendingIntent(R.id.group_heading, openApp)
                widget.addView(R.id.widget_rows, row)
            }
            manager.updateAppWidget(id, widget)
        }
    }

    companion object {
        private const val ACTION_TOGGLE = "com.rangdhanu.scheduler.TOGGLE_WIDGET_GROUP"
        private const val EXTRA_GROUP = "group"
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TaskWidget::class.java))
            if (ids.isNotEmpty()) TaskWidget().onUpdate(context, manager, ids)
        }
    }
}
