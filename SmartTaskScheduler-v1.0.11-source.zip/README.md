Smart Task Scheduler v1.0.6 Android source. See SIGNING_AND_BACKUP.md. Upload only this ZIP to the repository root; use build-from-zip-v1.0.6.yml as the repository workflow.
