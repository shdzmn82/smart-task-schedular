# v1.0.6 — Safe updates and Drive backup

## Important: existing installation
Android only accepts an in-place update when the applicationId and signing certificate match, and versionCode does not decrease. This project keeps applicationId `com.rangdhanu.scheduler` and increases versionCode to 6. **It cannot recover the signing certificate of an APK already installed.** If that certificate differs, installation will still fail. Do not uninstall the existing app until its tasks have been backed up.

## Drive backup and restore
In the app select **Google Drive / ফাইলে Backup**; choose Google Drive in Android's document picker, then Save. This creates a JSON file containing categories and tasks. For Restore, choose the saved JSON in the picker and confirm replacement. This is manual backup, not automatic cloud sync. Restore replaces current tasks and categories. Keep an extra backup copy.

## Stable signing for future builds
Generate one private Android release keystore securely, retain it in a safe place, and configure these GitHub Actions repository secrets:
- `STS_KEYSTORE_BASE64`: base64 of the entire keystore file (single line)
- `STS_KEYSTORE_PASSWORD`: keystore password
- `STS_KEY_ALIAS`: key alias
- `STS_KEY_PASSWORD`: key password

Never commit the keystore or passwords to GitHub. The workflow creates a release APK only when the secrets are supplied. Without secrets, it produces a debug APK for testing only, which may conflict with older installs. The same secrets must be retained for all future updates. GitHub Actions logs should not print secrets.

### Existing APK key limitation
If the currently installed APK was signed by an ephemeral GitHub runner debug key, this new stable release key **will not** update it. First export your data using the installed app if supported; otherwise retain the installed app and seek a compatible-key update before attempting replacement.
