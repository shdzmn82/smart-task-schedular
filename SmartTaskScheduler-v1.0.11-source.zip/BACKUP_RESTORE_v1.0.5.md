# Smart Task Scheduler v1.0.5 — Backup & Restore

- Tap **Google Drive / ফাইলে Backup** and choose Google Drive in Android's document picker (or local storage). A versioned JSON file is written to the location chosen.
- Tap **Google Drive / ফাইল থেকে Restore**, choose that JSON file, and confirm replacement of current tasks and categories.
- Restore validates the backup before changing data, writes tasks and categories together, then refreshes the widget and reminders.
- This is **manual** backup/restore via Android Storage Access Framework. It is not automatic cloud synchronization and requires the Google Drive app/provider to be available on the device.
- Before uninstalling the current app, create a backup with the currently installed version. Older versions without this feature cannot export a backup using this UI; do not uninstall them before data has been preserved by another method.
- Debug APK update may fail if the signing key changes. This feature does not resolve signature conflicts on its own.
- Source has not been compiled or device-tested in this environment.
